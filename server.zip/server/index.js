const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors')
const app = express();
const mysql = require('mysql')

const db = mysql.createPool({
    host: 'projectdb.cz6k4ospzich.ap-south-1.rds.amazonaws.com',
    user: 'admin',
    password: 'adminadmin',
    database: 'students'
})

app.use(cors());
app.use(express.json())
app.use(bodyParser.urlencoded({extended: true}))

app.get("/api/get", (req, res) => {
    const sqlGet = "SELECT * FROM student";
    db.query(sqlGet,(err, result) => {
        res.send(result);
        console.log(result);
    
    })
})

app.get("/",(req,res) => {
    console.log(res)
})

app.post("/api/insert", (req, res)=> {

    const fname = req.body.fname
    const lname = req.body.lname
    const rollno = req.body.rollno
    const branch = req.body.branch

    const sqlInsert = "INSERT INTO student (fname, lname, roll_no, branch) VALUES (?,?,?,?)";
    db.query(sqlInsert, [fname, lname, rollno, branch], (err, result)=> {

        console.log(result);

    });
});

app.delete("/api/delete/:roll_no", (req, res)=> {
    const rollno = req.params.roll_no;
    const sqlDelete = "DELETE FROM student WHERE roll_no = ?";
    db.query(sqlDelete, rollno, (err, result) => {
        if (err) console.log(err);
    });
});

app.put("/api/update", (req, res)=> {
    const fname = req.body.fname;
    const lname = req.body.lname;
    const rollno = req.body.rollno;
    const branch = req.body.branch;

    const sqlUpdate = "UPDATE student SET fname = ?, lname = ?, branch = ? WHERE roll_no = ?";
    db.query(sqlUpdate, [fname,lname,branch,rollno], (err, result) => {
        if (err) console.log(err);
    });
});

app.listen(3001, () => {
    console.log("running on port 3001");
});